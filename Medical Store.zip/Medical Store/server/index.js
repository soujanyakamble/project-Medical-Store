const express = require("express");
const app= express();
const bodyparser=require("body-parser");
const mysql=require("mysql");
const cors=require("cors");

const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'neha.2@ignitiv.com',
    database:'medical'
})
app.use(cors());
app.use(express.json());
app.use(bodyparser.urlencoded({extended: true}));

app.get("/api/get",(req,res)=>{
    const sqlget="SELECT * FROM medical.medicinedata";
     db.query(sqlget,(err,result) =>{
        res.send(result);
     })
})
app.get("/posts",(req,res)=>{
    const sqlget="SELECT * FROM medical.medicinedata";
     db.query(sqlget,(err,result) =>{
        res.send(result);
     })
})
app.post("/api/post",(req,res)=>{
    const {id,medicine_name,ExpiryDate,MFGDate,Quantity}=req.body;
    const sqlInsert="insert into medicineData (id,medicine_name,ExpiryDate,MFGDate,Quantity)values(?,?,?,?,?)" ;

    db.query(sqlInsert,[id,medicine_name,ExpiryDate,MFGDate,Quantity],(error,result) =>{
if(error){
    console.log(error);
}
    });

})

app.post("/register",(req,res)=>{
    const {full_name,email,phone, password}=req.body;
    const sqlInsert="insert into userdata (full_name,email,phone, password)values(?,?,?,?)";

    db.query(sqlInsert,[full_name,email,phone, password],(error,result) =>{
if(error){
    console.log(error);
}res.send("Register");
    });

})

app.post("/login",(req,res)=>{
    const {email, password}=req.body;
    const sqlLogin="select * from userdata where email=? and password=?";

    db.query(sqlLogin,[email, password],(error,result) =>{
     
    res.send(result);
        
    });

})
app.get("/",(req,res)=>{
    // const sqlInsert="insert into medicineData (id,medicine_name,ExpiryDate,MFGDate,Quantity)values(32,'Coddld','23122023','23122023',20)" ;
    // db.query(sqlInsert,(err,result) =>{
    //     console.log("error", err);
    //     console.log("result",result);
    //     res.send("Hello express");
    // })
    
})


app.listen(5000,()=>{
console.log("server is running on port 5000");
})
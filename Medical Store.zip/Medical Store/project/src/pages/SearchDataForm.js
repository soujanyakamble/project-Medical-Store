import React, { useState} from "react";
import axios from "axios";

const App = (props) => {
    
    const [data, setData] = useState([]);
     

    const loaddata=async ()=>{
        const response=await axios.get("http://localhost:5000/api/get");
        setData(response.data);
    };
 
  const people = [
    { name: "Paracetmol", ExpDate: "11/12/2024", MFD:"12/12/2023", id: 1 },
    { name: "Omi", ExpDate: "11/12/2024", MFD:"2/12/2023", id: 2 },
    { name: "cipla", ExpDate: "11/12/2024",MFD:"12/1/2023", id: 3 },
    { name: "nise", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 4 },
    { name: "combiflam", ExpDate: "11/12/2024",MFD:"11/12/2023", id: 5 },
    { name: "chlorophin", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 6 },
    { name: "Amoxicillin", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 7 },
    { name: "acetamanophen", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 8 },
    { name: "Zesnivit", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 9 },
    { name: "Zincovit", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 10 }, 
    { name: "Aspirin", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 11 },
    { name: "Crocin", ExpDate: "11/12/2024",MFD:"12/12/2023", id: 12 }

  ];
 
  const [search, setNewSearch] = useState("");

  const handleSearchChange = (e) => {
    setNewSearch(e.target.value);
  };

  const filtered = !search
    ? people
    : people.filter((person) =>
        person.name.toLowerCase().includes(search.toLowerCase())
      );
       
     
  return (
    < >
    <div className="container-fluid d-flex justify-content-center  "style={{backgroundColor:"#C0C0C0"}} >
        <div className="row col-10  text-center bg-white border border-dark rounded mt-3 mb-3">
      <h2 className="col-4  w-25" style={{color:"#950c0c"}}>Medicine Data:</h2>
    
      <input type="text" className="w-50 border-primary m-2" value={search} onChange={handleSearchChange} />
       
      {filtered.map((person) => {
        return (
            <table className="table border border-striped  bg-info text-dark">
                  <tbody>
                 <tr >
                    <td className="p-2" style={{textAlign:"left",width:"25%"}}>{person.id}</td>
                    <td style={{textAlign:"left",width:"25%"}}>{person.name}</td>
                    <td style={{textAlign:"left",width:"25%"}}>{person.MFD}</td>
                    <td style={{textAlign:"left",width:"25%"}}>{person.ExpDate}</td>
                 </tr>
          
                
                </tbody>
                 
          
          </table>
        );
      })}
      </div>
      </div>
    </>
  );
};

export default App;
import React, {Component,useEffect, useState} from 'react';


import FormValidator from './FormValidator';
import axios from "axios";
import "./App.css";

class App extends Component{
  
constructor(){
    super();
    this.validator = new FormValidator([{
        field: 'email',
        method: 'isEmpty',
        validWhen: false,
        message: 'Enter your email address.'
        },{
            field: 'email',
            method: 'isEmail',
            validWhen: true,
            message: 'Enter valid email address.'
            },  
     {
    field: 'password',
    method: 'isEmpty',
    validWhen: false,
    message: 'Enter password.'
    }, 
]);
    
this.state = {
        email: '',
        password: '',
        validation: this.validator.valid(),
        }
        this.submitted = false;
    }
    handleInputChange = event => {
        event.preventDefault();
        this.setState({
        [event.target.name]: event.target.value,
        });
        }
        handleFormSubmit = event => {
            event.preventDefault();
            const validation = this.validator.validate(this.state);
            this.setState({
            validation
            });
            this.submitted = true;
            if(validation.isValid) {
            //reaches here if form validates successfully...
            }
            }

            
      
render() {
    let validation = this.submitted ?this.validator.validate(this.state) : this.state.validation
    return (
      <div className="container mb-4">
      <div className="row d-flex justify-content-center">
      <div className="col-md-4 col-md-offset-4 p-4 bgg ">
      <p className="title text-center">Login Form</p>

      <form className="App">
      
      <div className={validation.email.isInvalid && 'has-error'} >
      <label className="vtt" htmlFor="email">Email address</label>
      <input type="email" className="form-control" name="email" placeholder="Email address" 
      onChange={this.handleInputChange} /> <span className="help-block">{validation.email.message}</span>
       </div>
      <div className={validation.password.isInvalid && 'has-error'}>
      <label className="vtt" htmlFor="password">Password</label>
      <input type="password" className="form-control" placeholder="Password" name="password" 
      onChange={this.handleInputChange} /> <span className="help-block">{validation.password.message}</span> 
      </div>
      <button onClick={this.handleFormSubmit} className="btn1 btn-primary">Login </button>
     
      </form>
    </div>
    </div>
    </div>
  );
}
}
export default App;

import React from 'react';


const About = () => {
  return (
    <div className="container-fluid mt-3">
    <div className="row row-cols-1 row-cols-md-3 g-4"style={{backgroundColor:"#C0C0C0"}}>
  <div className="col my-5">
    <div className="card h-70">
      <img src="support4.jpg" className="card-img-top" alt="..."/>
      <div className="card-body">
        <h5 className="card-title">SUPPORT 24/7</h5>
        <p className="card-text">It is a long established fact that a reader will be distracted
           This is a wider card with supporting text below as a natural lead-in</p>
      </div>
     
    </div>
  </div>
  <div className="col my-5">
    <div className="card h-100">
      <img src="licence1.jpg" className="card-img-top" alt="..."/>
      <div className="card-body">
        <h5 className="card-title">LICENCE OF GOVERNMENT</h5>
        <p className="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
      </div>
      
    </div>
  </div>
  <div className="col my-5">
    <div className="card h-100">
      <img src="tport5.jpg" className="card-img-top" alt="..."/>
      <div className="card-body">
        <h5 className="card-title">FAST DELIVERY</h5>
        <p className="card-text">It is a long established fact that a reader will be distracted
           This is a wider card with supporting text below as a natural lead-in</p>
      </div>
      
    </div>
  </div>
</div>
</div>
  )
}

export default About

const Post = ({ post }) => {
    return (
        <article>
            <h2>{post.id}</h2>
            <h2>{post.medicine_name}</h2>
            <p>{post.ExpiryDate}</p>
            <p>{post.MFGDate}</p>
            <p>{post.Quantity}</p>
        </article>
    )
}
export default Post
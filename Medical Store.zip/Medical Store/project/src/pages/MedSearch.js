import axios from "axios"
import { useState, useEffect } from 'react'
import SearchBar from './SearchBar'
import ListPage from './ListPage'


export const api = axios.create({
    baseURL: 'http://localhost:5000/'
})

export const getPostsData = async () => {
    const response = await api.get('/posts')
    return response.data
}
function App() {
  const [posts, setPosts] = useState([])
  const [searchResults, setSearchResults] = useState([])

  useEffect(() => {
    getPostsData().then(json => {
      setPosts(json)
      setSearchResults(json)
    })
  }, [])



  return (
    <>
      <SearchBar posts={posts} setSearchResults={setSearchResults} />
      <ListPage searchResults={searchResults} />
    </>
  )
}

export default App;

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./Home.css";
import axios from "axios";
import { toast } from "react-toastify";

const Medicine = () =>{
    const [data, setData] = useState([]);

    const loaddata=async ()=>{
        const response=await axios.get("http://localhost:5000/api/get");
        setData(response.data);
    };
    useEffect(()=>{
        loaddata();
    },[] );

    return(
        <div  className=" container mb-4 ">
          <div className="d-flex justify-content-center ">
            <Link to="/addcontact">
            <button className="btn bg-info btn-medicine">Add Medicine</button> 
            </Link>
            <Link to="/home">
            <button className="btn bg-danger btn-medicine" Style={{marginleft:"100px"}}>Logout</button> 
            </Link>
          </div>
         
           <table className="styled-table w-100">
             <thead>
             <tr>
                <th style={{ textAlign: "left",width:"25%" }}>Id.</th>
                <th style={{ textAlign: "left",width:"25%" }}>Medicine Name</th>
                <th style={{ textAlign: "left",width:"25%" }}>Expiry Date</th>
                <th style={{ textAlign: "left",width:"25%" }}>Quantity</th>
               
            </tr>
        </thead>
        <tbody>
          {data &&
            data.map((item, index) => {
              return (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{item.medicine_name}</td>
                  <td>{item.ExpiryDate}</td> 
                  <td>{item.Quantity}</td>
                  
                  <td>

                  </td>
                </tr>
              );
            })}
        </tbody>
          </table>
        </div>
    )
}
export default Medicine;
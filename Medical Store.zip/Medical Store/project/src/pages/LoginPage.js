import { useState } from "react"
import { useNavigate } from "react-router"
import axios from "axios"
import { Link } from "react-router-dom";

export default function Login1()
{
 
  let [email,setMob] = useState("")
  let [password,setPassword] = useState("")
  let navigate = useNavigate()
  
  //const dispatch= useDispatch()
 
  function loginHandler()
  {
        console.log({email,password})

        axios.post('http://localhost:5000/login',{email ,password})
      .then(data =>{
            console.log(data.data)
           if(data.data == "" )
           { 
            console.log("/LoginPage")
            alert("Invalid Credentials!!")
              navigate("/LoginPage")
           }else{
         
            console.log("/medicine")
           
            navigate("/medicine")
           }
      } );
              

}


    return(
        <>
        
        <section className=" mb-2" style={{"backgroundColor": "#b6c6d8"}}>
            <div className="container py-1 h-100">
              <div className="row d-flex justify-content-center align-items-center h-100">
                <div className="col col-xl-10">
                  <div className="card" style={{"borderRadius": "1rem"}}>
                    <div className="row g-0"style={{height:"490px"}}>
                      <div className="col-md-8 col-lg-6 d-none d-md-block " style={{height:"490px"}}>
                        <img src="loginimg3.jpg" width="100%" height="100%"
                          alt="login form"  style={{"borderRadius": "1rem 0 0 1rem"}}  />
                      </div>
                      <div className="col-md-4 col-lg-6 d-flex align-items-center"style={{height:"490px"}}>
                        <div className="card-body p-4 p-lg-5 text-black">
          
                            <div className="d-flex align-items-center mb-3 pb-1">
                             
                              <span className="h1 fw-bold mt-5 mb-0" style={{"text-align":"center"}}>Sign In</span>
                            </div>
          
                            

                            <div className="form-outline mb-1">
                            <label className="form-label" htmlFor="form2Example17">Email address</label>
                              <input type="email" id="form2Example17" name="uname" placeholder=" Email "className="form-control form-control-lg" onBlur={(e)=>{setMob(e.target.value)}}/>
                             
                            </div>
          
                            <div className="form-outline mb-1">
                            <label className="form-label" htmlFor="form2Example27">Password</label>
                              <input type="password" id="form2Example27" placeholder="Password" name="password" className="form-control form-control-lg" onBlur={(e)=>{setPassword(e.target.value)}}/>
                              
                            </div>
          
                            <div className="pt-1 mb-1">
                              <button className="btn btn-dark btn-lg btn-block" type="button" onClick={loginHandler}>Sign In</button>
                            </div>
          
                            
                            <p className="mb-1 pb-lg-2" style={{"color": "#393f81"}}>Don't have an account?
                               </p>
                               <Link to="/Registration" className="text-decoration-none">
                                Registration
                               </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

        </>
    )
}

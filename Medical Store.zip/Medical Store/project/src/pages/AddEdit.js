import React, { useState, useEffect } from "react";
import { useNavigate  } from "react-router-dom";
import { Link } from "react-router-dom";
import "./AddEdit.css";
import { toast } from "react-toastify";
import axios from "axios";

const initialState = {
    id:"",
    medicine_name: "",
    ExpiryDate: "",
    MFGDate: "",
    Quantity:"",
  }; 
const AddEdit = () => {
    const [state, setState] = useState(initialState);
  const { id, medicine_name, ExpiryDate, MFGDate,Quantity } = state;

  
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!id ||!medicine_name || !ExpiryDate || !MFGDate || !Quantity) {
        toast.error("Please provide value in each input field");
      } else {
        axios.post("http://localhost:5000/api/post",{
            id,
            medicine_name,
             ExpiryDate,
              MFGDate,
              Quantity
        }).then(()=>{
            setState({id:0, medicine_name:"", ExpiryDate:"", MFGDate:"",Quantity:""})
        } ).catch((error)=> toast.error(error.response.data))
        
      }
}
  const handleInputChange = (e) => {
    let { name, value } = e.target;
    setState({
      ...state,
      [name]: value,
    });
  };
  
  return (
    <div  style={{ marginTop: "10px" }}>
     
      <h4 className="text-center">Add Medicine</h4>
    <form className="bg-info text-white mb-2"
      style={{
        margin:"auto",
        padding: "5px",
       
        maxWidth: "400px",
        alignContent: "center",
      }}
      onSubmit={handleSubmit}
    >
     <label htmlFor="id">id</label>
      <input
        type="number"
        id="id"
        name="id"
        placeholder="Enter No..."
        value={id}
        onChange={handleInputChange}
      />
      <label htmlFor="medicine_name">Medicine Name</label>
      <input
        type="text"
        id="medicine_name"
        name="medicine_name"
        placeholder="Enter Medicine Name..."
        value={medicine_name}
        onChange={handleInputChange}
      />

      <label htmlFor="expiryDate">ExpiryDate</label>
      <input
        type="text"
        id="ExpiryDate"
        name="ExpiryDate"
        placeholder="Enter ExpiryDate"
        value={ExpiryDate}
        onChange={handleInputChange}
      />

      <label htmlFor="MFGDate">MFGDate</label>
      <input
        type="text"
        id="MFGDate"
        name="MFGDate"
        placeholder="Enter MFGDate..."
        value={MFGDate}
        onChange={handleInputChange}
      />
      <label htmlFor="Quantity">Quantity</label>
      <input
        type="text"
        id="Quantity"
        name="Quantity"
        placeholder="Enter Quantity..."
        value={Quantity}
        onChange={handleInputChange}
      />

      <input type="submit" value="Save" />
      <Link to="/Medicine">
        <input type="button" className="btn1" value="Go Back"></input>
      </Link>
    </form>
   
  </div>
  )
}

export default AddEdit

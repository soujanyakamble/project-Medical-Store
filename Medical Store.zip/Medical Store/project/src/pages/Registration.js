import React, { useState, useEffect } from "react";
import { useNavigate  } from "react-router-dom";
import { Link } from "react-router-dom";
import "./AddEdit.css";
import { toast } from "react-toastify";
import axios from "axios";

const initialState = {
    full_name:"",
    email: "",
    phone: "",
    password: "",
    ConfirmPassword:"",
  }; 
const Registration = () => {
    const [state, setState] = useState(initialState);
  const { full_name, email, phone, password,ConfirmPassword } = state;
  let navigate = useNavigate()
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!full_name ||!email || !phone || !password || !ConfirmPassword) {
        toast.error("Please provide value in each input field");
      } else {
        axios.post("http://localhost:5000/register",{
            full_name,
            email,
             phone,
              password
        }).then(data =>{
          if(data.data == "Register" )
          { 
           console.log("/LoginPage")
           alert("Register Successfully!!")
             navigate("/LoginPage")
          }else{
        
           navigate("/LoginPage")
          }
    } );
      }
}
  const handleInputChange = (e) => {
    let { name, value } = e.target;
    setState({
      ...state,
      [name]: value,
    });
  };
  
  return (
    
    <div  style={{ marginTop: "20px", height:"400px",marginBottom: "182px"  }}>
      <h2 className="text-center">Registration Form</h2>
    <form className="bg-info text-white"
      style={{
        margin: "auto",
        padding: "15px",
        maxWidth: "400px",
        alignContent: "center",
      }}
      onSubmit={handleSubmit}
    >
     <label htmlFor="full_name">Full Name</label>
      <input
        type="text"
        id="full_name"
        name="full_name"
        placeholder="Enter full_name..."
        value={full_name}
        onChange={handleInputChange}
      />
      <label htmlFor="email">email</label>
      <input
        type="text"
        id="email"
        name="email"
        placeholder="Enter Email Id..."
        value={email}
        onChange={handleInputChange}
      />

      <label htmlFor="phone">Phone No</label>
      <input
        type="text"
        id="phone"
        name="phone"
        placeholder="Enter Phone No.."
        value={phone}
        onChange={handleInputChange}
      />

      <label htmlFor="password">Password</label>
      <input
        type="password"
        id="password"
        name="password"
        placeholder="Enter password..."
        value={password}
        onChange={handleInputChange}
      />
      <label htmlFor="ConfirmPassword">Confirm Password</label>
      <input
        type="password"
        id="ConfirmPassword"
        name="ConfirmPassword"
        placeholder="Confirm Password.."
        value={ConfirmPassword}
        onChange={handleInputChange}
      />
      <input type="submit" value="Register" />
       
    </form>
  </div>
  )
}

export default Registration

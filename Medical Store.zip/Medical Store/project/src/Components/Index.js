import React from "react";
import { Nav, NavLink, NavMenu }
	from "./NavbarElements";

const index = () => {
return (
	<>
	
	<nav className="navbar navbar-expand-lg  text-white  p-0" style={{backgroundColor:"rgb(11 93 124)"}}>
  <div className="container-fluid">
	<div className="d-flex" >
        
   <h1> <a className="navbar-brand "style={{color:"#83f1e7",fontSize:"30px",fontWeight:"bold"}} >Medico</a></h1>
	</div>
    <button className="navbar-toggler bg-info" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon "></span>
    </button>
	
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
	<Nav className="" style={{backgroundColor:"rgb(11 93 124)",fontSize:"18px",fontWeight:"bold"}}>
		<NavMenu className="collapse navbar-collapse" id="navbarSupportedContent">
		<NavLink to="/home" className="text-white nav-item active" activestyle>
			Home
		</NavLink>
		
		<NavLink to="/about" className="text-white" activestyle>
			About
		</NavLink>
		
		
		 <NavLink to="/SearchDataForm" className="text-white" activestyle>
		 Search Medicine
		</NavLink>
		
		
		
		</NavMenu>
	</Nav>
	</div>
	<div>
	
	<NavLink to="/LoginPage" className="text-info d-flex juatify-content-space-between"style={{backgroundColor:"rgb(11 93 124)",fontSize:"20px",fontWeight:"bold"}}  activestyle>
	<i class="fa-sharp fa-solid fa-user"></i>	    Login
		</NavLink>
	</div>
  </div>
</nav>
	</>
);
};

export default index;

import React from 'react';


const Footer = () => {
  return (
    <div className=''>
      
<footer className="text-center text-lg-start text-white text-muted bg-secondary h-200 ">
  
  <section className="d-flex justify-content-center justify-content-lg-between p-2 border-bottom text-white">
   
    <div className="me-5 d-none text-info  d-lg-block">
      <span className="font-weight-bold">Get connected with us on social networks:</span>
    </div>
    

    
    <div className=''>
      <a href="" className="me-4 link-secondary">
        <i className="fab fa-facebook-f text-info"/>
      </a>
     
      <a href="" className="me-4 link-secondary">
        <i className="fab fa-linkedin text-info"/>
      </a>
      <a href="" className="me-4 link-secondary">
        <i className="fab fa-github text-info"/>
      </a>

      <a href="" className="me-4 link-secondary">
        <i className="fab fa-twitter text-info text-info"/>
      </a>
    </div>
    
  </section>
  

 
  <section className="">
    <div className="container-fluid text-center text-md-start mt-1 text-white">
     
      <div className="row mt-2">
        
        <div className="col-md-3 col-lg-4 col-xl-3 mx-auto mb-1">
          
          <h6 className="text-uppercase fw-bold mb-2 text-info">
            <i className="fas fa-gem me-3 text-white"></i>Medico
          </h6>
          <p>
          The doctor sees all the weakness of mankind; the lawyer all the wickedness, the theologian …
The art of medicine consists in amusing the patient while nature cures the disease. Voltaire.
Nature can do more than physicians. Oliver Cromwell .
          </p>
        </div>
       

        
        <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4 ">
         
          <h6 className="text-uppercase fw-bold mb-4 text-info ">
            Products
          </h6>
          <p>
            <a href="https://www.ignitiv.com/services/" className="text-reset text-decoration-none">Cosmetics</a>
          </p>
          <p>
            <a href="https://www.ignitiv.com/services/" className="text-reset text-decoration-none">Baby Care</a>
          </p>
          <p>
            <a href="https://www.ignitiv.com/services/" className="text-reset text-decoration-none">Multi Vitamins</a>
          </p>
          
        </div>
        

        
        <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
         
          <h6 className="text-uppercase fw-bold mb-4 text-info">
            Useful links
          </h6>
          <p>
            <a href="https://www.ignitiv.com/solutions/cx-solutions-ecommerce/" className="text-reset text-decoration-none">Pricing</a>
          </p>
          <p>
            <a href="https://www.ignitiv.com/solutions" className="text-reset text-decoration-none">Settings</a>
          </p>
          <p>
            <a href="https://www.ignitiv.com/solutions" className="text-reset text-decoration-none">Help</a>
          </p>
        </div>
        

        
        <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
         
          <h6 className="text-uppercase fw-bold mb-4 text-info">Contact</h6>
          <p><i className="fas fa-home me-3 text-white"></i> Hinjewadi, HY 10012, US</p>
          <p>
            <i className="fas fa-envelope me-3 text-white"></i>
            mailto:medicalstore@example.com
          </p>
          <p><i className="fas fa-phone me-3 text-white"></i> + 01 234 567 88</p>
          <p><i className="fas fa-print me-3 text-white"></i> + 01 234 567 89</p>
        </div>
        
      </div>
      
    </div>
  </section>
  

 
  <div className="text-center p-1 bg-info text-dark" >
    © 2021 Copyright:
    <a className="text-reset fw-bold" href="https://mdbootstrap.com/">Medicalstore.com</a>
  </div>
 
</footer>

    </div>
  )
}

export default Footer